%GUI_RMT
%Author: Sheldon Van Middelkoop
%Description: The graphical user interface and main program for conductivity
%measurements for the water filtration systems.
%Version: 1.2
%Date: 1/23/2018

function varargout = GUI_RMT(varargin)
    % GUI_RMT MATLAB code for GUI_RMT.fig
    %      GUI_RMT, by itself, creates a new GUI_RMT or raises the existing
    %      singleton*.
    %
    %      H = GUI_RMT returns the handle to a new GUI_RMT or the handle to
    %      the existing singleton*.
    %
    %      GUI_RMT('CALLBACK',hObject,eventData,handles,...) calls the local
    %      function named CALLBACK in GUI_RMT.M with the given input arguments.
    %
    %      GUI_RMT('Property','Value',...) creates a new GUI_RMT or raises the
    %      existing singleton*.  Starting from the left, property value pairs are
    %      applied to the GUI before GUI_RMT_OpeningFcn gets called.  An
    %      unrecognized property name or invalid value makes property application
    %      stop.  All inputs are passed to GUI_RMT_OpeningFcn via varargin.
    %
    %      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
    %      instance to run (singleton)".
    %
    % See also: GUIDE, GUIDATA, GUIHANDLES

    % Edit the above text to modify the response to help GUI_RMT

    % Last Modified by GUIDE v2.5 03-Apr-2018 17:00:37

    % Begin initialization code - DO NOT EDIT
    gui_Singleton = 1;
    gui_State = struct('gui_Name',       mfilename, ...
                       'gui_Singleton',  gui_Singleton, ...
                       'gui_OpeningFcn', @GUI_RMT_OpeningFcn, ...
                       'gui_OutputFcn',  @GUI_RMT_OutputFcn, ...
                       'gui_LayoutFcn',  [] , ...
                       'gui_Callback',   []);
    if nargin && ischar(varargin{1})
        gui_State.gui_Callback = str2func(varargin{1});
    end

    if nargout
        [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
    else
        gui_mainfcn(gui_State, varargin{:});
    end
    % End initialization code - DO NOT EDIT


% --- Executes just before GUI_RMT is made visible.
function GUI_RMT_OpeningFcn(hObject, eventdata, handles, varargin)
    % This function has no output args, see OutputFcn.
    % hObject    handle to figure
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    structure with handles and user data (see GUIDATA)
    % varargin   command line arguments to GUI_RMT (see VARARGIN)

    % Choose default command line output for GUI_RMT
    handles.output = hObject;

    % Update handles structure
    guidata(hObject, handles);

    % UIWAIT makes GUI_RMT wait for user response (see UIRESUME)
    % uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = GUI_RMT_OutputFcn(hObject, eventdata, handles) 
    % varargout  cell array for returning output args (see VARARGOUT);
    % hObject    handle to figure
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    structure with handles and user data (see GUIDATA)

    % Get default command line output from handles structure
    varargout{1} = handles.output;



% --- Executes on button press in pushbutton2.
function pb2 = pushbutton2_Callback(hObject, eventdata, handles)
    % hObject    handle to pushbutton2 (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    structure with handles and user data (see GUIDATA)
    
    %If the user presses the close button it closes the gui
    pb2 = get(handles.pushbutton2, 'Value');
    if(pb2)
        close(GUI_RMT);
    end
    


%Please keep this header just as reference. Thanks S.V.
function time_Callback(hObject, eventdata, handles)
    % hObject    handle to time (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    structure with handles and user data (see GUIDATA)

    % Hints: get(hObject,'String') returns contents of time as text
    %        str2double(get(hObject,'String')) returns contents of time as a double
    
    

% --- Executes during object creation, after setting all properties.
function time_CreateFcn(hObject, eventdata, handles)
% hObject    handle to time (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu1.
function input = popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1

%Retreive index from popup_menu/pulldown
index = get(handles.popupmenu1,'Value');
%output the current step size corresponding to the given index
switch index
    case 1
        input = 0.02;
    case 2
        input = 0.04;
    case 3
        input = 0.06;
    case 4
        input = 0.08;
    case 5
        input = 0.1;
    % If error close gui
    otherwise
        close(GUI_RMT);
end



% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu2.
function input = popupmenu2_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu2

%Retreive index from popup_menu/pulldown
index = get(handles.popupmenu2,'Value');
%output the current step size corresponding to the given index
switch index
    case 1
        input = 0.004;
    case 2
        input = 0.006;
    case 2
        input = 0.008;
    case 3
        input = 0.01;
    % If error close gui
    otherwise
        close(GUI_RMT);
end



% --- Executes during object creation, after setting all properties.
function popupmenu2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



% --- Executes on button press in checkbox1.
function input = checkbox1_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox1

%Determines whether the user wants a control experiment (invalid)
input = get(handles.checkbox1, 'Value');



% --- Executes on button press in checkbox2.
function input = checkbox2_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox2

%Determines whether user wants error bars
input = get(handles.checkbox2, 'Value');



% --- Executes on button press in checkbox3.
function input = checkbox3_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox3

%Determines if user wants to save data
input = get(handles.checkbox3, 'Value');




function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double



% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end




function resDec_Callback(hObject, eventdata, handles)
% hObject    handle to resDec (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of resDec as text
%        str2double(get(hObject,'String')) returns contents of resDec as a double


% --- Executes during object creation, after setting all properties.
function resDec_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resDec (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



    
% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
    % hObject    handle to pushbutton1 (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    structure with handles and user data (see GUIDATA)
    
    
    %We get both the value from the text boxed in the gui and whether or
    %not a type conversion from string to num (int/float/...) was possible
    [input, status] = str2num(get(handles.time, 'String'));
    [input2, status2] = str2num(get(handles.resDec, 'String'));
    
    %If we get valid numbers we can proceed
    if(status && input > 0 && status2 && input2 > 0) 
        time = input;
        resDec = input2;
        %If they press the start button 
        pb1 = get(handles.pushbutton1, 'Value');
        if(pb1)
           
            %Get the inputs from the other gui methods and pass to RMT as
            %function parameters.
            MaxI = popupmenu1_Callback(hObject, eventdata, handles);
            StepI = popupmenu2_Callback(hObject, eventdata, handles);
            control = checkbox2_Callback(hObject, eventdata, handles);
            error = checkbox1_Callback(hObject, eventdata, handles);
            saveD = checkbox3_Callback(hObject, eventdata, handles);
            
            if(~control)
                %handles exception processing
                close(GUI_RMT);
                Resistance_Meas_Time(MaxI, StepI, time, error, saveD, resDec)
            else
                %handles exception processing.
                close(GUI_RMT);
                Resistance_Meas_Time_Control(MaxI, StepI, time, error)
            end
            
        end
    else
        %If user placed incorrect data into text boxes it tells user to
        %correct issue in the GUI
        if(input <= 0)
            set(handles.time, 'String', 'Must be positive number');
        end
        if(input2 <= 0)
            set(handles.resDec, 'String', 'Must be a positive number.');  
        end
    end
     
            
