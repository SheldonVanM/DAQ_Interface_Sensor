function Gate_Voltage_Sweep( maxCurrent, deltaAmp, startVoltage, endVoltage, saveData, gain )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
    try
         %Open the emant card for IV curve between gate and source
         %This specifically opens COM port 7 (See SOP for details)
        hEmant_IV = actxserver('EMANT300COM.Wrapper', 'COM7'); %gains access to wrapper class.
        hEmant_IV.Open;
        close(GUI_Transistor);
    catch
        warndlg('Unable to make connection with controlling device at COM port 6. Please ensure proper connections and try again.');
        GUI_Transistor;
    end
    %Try to open the second EMANT card
    try
         %Open the emant card for gate source voltage
         %This specifically opens COM port 6 (See SOP for details)
        hEmant_GS = actxserver('EMANT300COM.Wrapper', 'COM6'); %gains access to wrapper class.
        hEmant_GS.Open;
        close(GUI_Transistor);
    catch
        warndlg('Unable to make connection with controlling device at COM port 7. Please ensure proper connections and try again.');
        GUI_Transistor;
    end
    
    %If user wants to save data to file
    if(saveData)
        fileID = fopen('Gate_Voltage_Sweep.txt','w');
        fprint( fileID, 'Gate Voltage \t\t\t Voltage_SD');
    end
    hold on
    %The colors that will be used in the plot legend
    colors = {'ro', 'bo', 'yo', 'go', 'co', 'mo'};
    deltaVolt = (endVoltage - startVoltage)/5; %We allow 5 points
    j = 1;
    Voltage_Gate = startVoltage:deltaVolt:endVoltage;
    %Create the legend
    Legend = cell(length(Voltage_Gate), 1);% For all possible legends
    currentRange = deltaAmp:deltaAmp:maxCurrent;
    %We will loop through gate voltage range
    for Voltage_Gate = startVoltage:deltaVolt:endVoltage

        volt_SD = [];
        i = 1;
        %This supplies the correct current to give the voltage the user
        %asked for
        hEmant_GS.WriteAnalog(Voltage_Gate/(2.2*gain))
        for amp = deltaAmp:deltaAmp:maxCurrent
            hEmant_IV.WriteAnalog(amp);
            volt_SD(i) = hEmant_IV.ReadAnalog('AIN_AIN2','AIN_AIN3');
            i = i + 1;
        end
        %Save data to file
        if(saveData)
            fprint( fileID, '%f \t\t\t %f', Voltage_Gate, volt);
        end
        %currentRange;
        %volt_SD;
        plot(volt_SD, currentRange, colors{j});
        Legend{j} = strcat('Gate Voltage = ', num2str(Voltage_Gate));
        %hold on
        j = j + 1;  
    end
    %Close the file where data is being saved
    if(saveData)
        fclose(fileID);
    end
    hold off
    hEmant_GS.WriteAnalog(0);
    hEmant_IV.WriteAnalog(0);
    %Add labels to plot
    title('Transistor Gate Sweep');
    xlabel('Voltage (Source-Drain)');
    ylabel('Current (Source-Drain)');
    legend(Legend);
    %Close both EMANT cards
    hEmant_IV.Close
    hEmant_GS.Close
end

