%GUI_Transistor
%Author: Sheldon Van Middelkoop
%Description: The graphical user interface and main program for conductivity
%measurements for the water filtration systems.
%Version: 1.2
%Date: 1/15/2018

function varargout = GUI_Transistor(varargin)
% GUI_TRANSISTOR MATLAB code for GUI_Transistor.fig
%      GUI_TRANSISTOR, by itself, creates a new GUI_TRANSISTOR or raises the existing
%      singleton*.
%
%      H = GUI_TRANSISTOR returns the handle to a new GUI_TRANSISTOR or the handle to
%      the existing singleton*.
%
%      GUI_TRANSISTOR('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUI_TRANSISTOR.M with the given input arguments.
%
%      GUI_TRANSISTOR('Property','Value',...) creates a new GUI_TRANSISTOR or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before GUI_Transistor_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to GUI_Transistor_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help GUI_Transistor

% Last Modified by GUIDE v2.5 20-Feb-2019 18:45:10

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @GUI_Transistor_OpeningFcn, ...
                   'gui_OutputFcn',  @GUI_Transistor_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before GUI_Transistor is made visible.
function GUI_Transistor_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to GUI_Transistor (see VARARGIN)

% Choose default command line output for GUI_Transistor
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes GUI_Transistor wait for user response (see UIRESUME)
% uiwait(handles.figure1);

%We start by disabling certain button which should not be allowed to be
%pressed
set(handles.StartVoltageEdit,'Enable','off')
set(handles.EndVoltageEdit,'Enable','off')
set(handles.StaticGateVoltage, 'Enable', 'on');


% --- Outputs from this function are returned to the command line.
function varargout = GUI_Transistor_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

%Empty header functions
function startVoltage_CreateFcn(hObject, eventdata, handles)
function startVoltage_Callback(hObject, eventdata, handles)

% --- Executes on selection change in Max_Current_Popup.
function maxCurrent = Max_Current_Popup_Callback(hObject, eventdata, handles)
% hObject    handle to Max_Current_Popup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns Max_Current_Popup contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Max_Current_Popup

%Retreive index from popup_menu/pulldown
index = get(handles.Max_Current_Popup, 'Value');
switch index
    %output the current step size corresponding to the given index
    case 1
        maxCurrent = 0.02;
    case 2
        maxCurrent = 0.04;
    case 3
        maxCurrent = 0.06;
    case 4
        maxCurrent = 0.08;
    case 5
        maxCurrent = 0.1;
    % If error close gui
    otherwise
        close(GUI_Transistor);
end


% --- Executes during object creation, after setting all properties.
function Max_Current_Popup_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Max_Current_Popup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu2.
function stepSize = popupmenu2_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu2
index = get(handles.popupmenu2, 'Value');
switch index
    case 1
        stepSize = 0.004;
    case 2
        stepSize = 0.006;
    case 3
        stepSize = 0.008;
    case 4
        stepSize = 0.01;
    otherwise
        close(GUI_Transistor);
end


% --- Executes during object creation, after setting all properties.
function popupmenu2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Begin.
function Begin_Callback(hObject, eventdata, handles)
% hObject    handle to Begin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
start = get(handles.Begin, 'Value');
if(start)
    maxCurrent = Max_Current_Popup_Callback(hObject, eventdata, handles);
    stepSize = popupmenu2_Callback(hObject, eventdata, handles);
    scanTime = scanTime_Callback(hObject, eventdata, handles);
    decadeRes = decadeResistance_Callback(hObject, eventdata, handles);
    saveData = saveDataRadioBtn_Callback(hObject, eventdata, handles);
    error = errorBarsRadioBtn_Callback(hObject, eventdata, handles);
    sweep = gateVoltageSweep_Callback(hObject, eventdata, handles);
    gain = Feedback_Callback(hObject, eventdata, handles);
    if(sweep)
        startVol = StartVoltageEdit_Callback(hObject, eventdata, handles);
        endVol = EndVoltageEdit_Callback(hObject, eventdata, handles);
        %Now call function
        Gate_Voltage_Sweep( maxCurrent, stepSize, startVol, endVol, saveData, gain )
    else
        staticVol = StaticGateVoltage_Callback(hObject, eventdata, handles);
        %Now call function
        Transistor_IV( maxCurrent, stepSize, scanTime, decadeRes, saveData, error, staticVol, gain);
    end
end

% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
cancel = get(handles.pushbutton2, 'Value');
if(cancel == 1)
    close(GUI_Transistor);
end


function scanTime = scanTime_Callback(hObject, eventdata, handles)
% hObject    handle to scanTime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of scanTime as text
%        str2double(get(hObject,'String')) returns contents of scanTime as a double
[input, status] = str2num(get(handles.scanTime, 'String'));

if(status && input > 0)
    scanTime = input;
else
    set(handles.scanTime, 'String', 'Must be a positive number');
end

% --- Executes during object creation, after setting all properties.
function scanTime_CreateFcn(hObject, eventdata, handles)
% hObject    handle to scanTime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function resDec = decadeResistance_Callback(hObject, eventdata, handles)
% hObject    handle to decadeResistance (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of decadeResistance as text
%        str2double(get(hObject,'String')) returns contents of decadeResistance as a double
[input, status] = str2num(get(handles.decadeResistance, 'String'));

if(status && input >= 0)
    resDec = input;
else
    set(handles.decadeResistance, 'String', 'Must be a positive number');
end

% --- Executes during object creation, after setting all properties.
function decadeResistance_CreateFcn(hObject, eventdata, handles)
% hObject    handle to decadeResistance (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in saveDataRadioBtn.
function save = saveDataRadioBtn_Callback(hObject, eventdata, handles)
% hObject    handle to saveDataRadioBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of saveDataRadioBtn
save = get(handles.saveDataRadioBtn, 'Value');

% --- Executes on button press in errorBarsRadioBtn.
function error = errorBarsRadioBtn_Callback(hObject, eventdata, handles)
% hObject    handle to errorBarsRadioBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of errorBarsRadioBtn
error = get(handles.errorBarsRadioBtn, 'Value');


% --- Executes on button press in gateVoltageSweep.
function sweep = gateVoltageSweep_Callback(hObject, eventdata, handles)
% hObject    handle to gateVoltageSweep (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of gateVoltageSweep
sweep = get(handles.gateVoltageSweep, 'Value');
    if(sweep == 1)
        set(handles.StartVoltageEdit,'Enable','on')
        set(handles.EndVoltageEdit,'Enable','on')
        set(handles.StaticGateVoltage, 'Enable', 'off');
    else
        set(handles.StartVoltageEdit,'Enable','off')
        set(handles.EndVoltageEdit,'Enable','off')
        set(handles.StaticGateVoltage, 'Enable', 'on');
    end




% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EndVoltagePopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to StaticGateVoltage (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of StaticGateVoltage as text
%        str2double(get(hObject,'String')) returns contents of StaticGateVoltage as a double



function staticVol = StaticGateVoltage_Callback(hObject, eventdata, handles)
% hObject    handle to StaticGateVoltage (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of StaticGateVoltage as text
%        str2double(get(hObject,'String')) returns contents of StaticGateVoltage as a double
[input, status] = str2num(get(handles.StaticGateVoltage, 'String'));

if(status && input >= 0)
    staticVol = input;
else
    set(handles.StaticGateVoltage, 'String', 'Must be a positive number');
end

% --- Executes during object creation, after setting all properties.
function StaticGateVoltage_CreateFcn(hObject, eventdata, handles)
% hObject    handle to StaticGateVoltage (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end




function fb = Feedback_Callback(hObject, eventdata, handles)
% hObject    handle to Feedback (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Feedback as text
%        str2double(get(hObject,'String')) returns contents of Feedback as a double
[input, status] = str2num(get(handles.Feedback, 'String'));
fb = 0;
if(status && input >= 0)
    fb = input;
    fb = 1 + (fb/1000);
else
    set(handles.decadeResistance, 'String', 'Must be a positive number');
end


% --- Executes during object creation, after setting all properties.
function Feedback_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Feedback (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function startVol = StartVoltageEdit_Callback(hObject, eventdata, handles)
% hObject    handle to StartVoltageEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of StartVoltageEdit as text
%        str2double(get(hObject,'String')) returns contents of StartVoltageEdit as a double
    [input, status] = str2num(get(handles.StartVoltageEdit, 'String'));
    startVol = 0;
    if(status && input >= 0)
        startVol = input;
    else
        set(handles.StartVoltageEdit, 'String', 'Must be a positive number');
    end
    startVol

% --- Executes during object creation, after setting all properties.
function StartVoltageEdit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to StartVoltageEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function endVol = EndVoltageEdit_Callback(hObject, eventdata, handles)
% hObject    handle to EndVoltageEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EndVoltageEdit as text
%        str2double(get(hObject,'String')) returns contents of EndVoltageEdit as a double
    [input, status] = str2num(get(handles.EndVoltageEdit, 'String'));
    endVol = 0;
    if(status && input >= 0)
        endVol = input;
    else
        set(handles.EndVoltageEdit, 'String', 'Must be a positive number');
    end
    endVol

% --- Executes during object creation, after setting all properties.
function EndVoltageEdit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EndVoltageEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
