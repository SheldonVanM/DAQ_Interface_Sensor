%This code controls the first GUI called

%Function initializes GUI
%DO NOT TOUCH!!!
function varargout = Main_Gui(varargin)
% MAIN_GUI MATLAB code for Main_Gui.fig
%      MAIN_GUI, by itself, creates a new MAIN_GUI or raises the existing
%      singleton*.
%
%      H = MAIN_GUI returns the handle to a new MAIN_GUI or the handle to
%      the existing singleton*.
%
%      MAIN_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MAIN_GUI.M with the given input arguments.
%
%      MAIN_GUI('Property','Value',...) creates a new MAIN_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Main_Gui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Main_Gui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Main_Gui

% Last Modified by GUIDE v2.5 16-Jan-2019 13:12:53

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Main_Gui_OpeningFcn, ...
                   'gui_OutputFcn',  @Main_Gui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT
end

% --- Executes just before Main_Gui is made visible.
%This code sets up the event handling for GUI
%DO NOT TOUCH!!!!
function Main_Gui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Main_Gui (see VARARGIN)

% Choose default command line output for Main_Gui
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Main_Gui wait for user response (see UIRESUME)
% uiwait(handles.figure1);
end

% --- Outputs from this function are returned to the command line.
%DO NOT TOUCH!!!!
function varargout = Main_Gui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;
end

% --- Executes on selection change in popupmenu1.
%This function is responsible for the call back when the pulldown/popup
%menu is interacted with
%We want to return the index of the popup menu to know which item was
%selected
function index = popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1

%The variable index is retrieved from the popup menu
index = get(handles.popupmenu1,'Value');
%0 will be for resistor and 1 will be for transistor
end


% --- Executes during object creation, after setting all properties.
% This sets up the popup menu
%DO NOT TOUCH!!!
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

% --- Executes on button press in pushbutton1.

%This sets up the start button call back (triggered when start button is
%clicked)
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Continue to next gui

%Retrieve index from the pulldown/popup menu
index = popupmenu1_Callback(hObject, eventdata, handles);

    %The first index is the pull down for the standard GUI chemiresistor
    if(index == 1)
        %Open the GUI for chemiresistor
        GUI_RMT
        %Close this GUI
        close(Main_Gui);
    end
    if(index == 2)
        %Open triode GUI
        GUI_Transistor
        %Close this GUI
        close(Main_Gui);
    else
        %Error checking
        close(Main_Gui);
    end
end


% --- Executes on button press in pushbutton2.
%This is the cancel button callback (triggered when button is clicked)
function pb2 = pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

    %Get integer value (1 if clicked)
    pb2 = get(handles.pushbutton2, 'Value');
    %If button is clicked then close the GUI/End program
    if(pb2)
        close(Main_Gui);
    end
end