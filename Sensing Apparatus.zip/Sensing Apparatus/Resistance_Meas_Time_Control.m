%Description:
%Program to push out a current and measure a voltage
%Will plot with respect to time.
%Test case for more complex program to do sensing of conductivity
function Resistance_Meas_Time_Control(Amax, deltaA, tmax, error)
    %clear all;
    %close('all'); %close any other functions
    %clc; %clear the command window
    try
        %Open the emant card
        hEmant300 = actxserver('EMANT300COM.Wrapper'); %gains access to wrapper class.
        hEmant = actxserver('Emant300COM.Wrapper');
        
        hEmant300.Open;
        hEmant.Open;
        h300name = hEmant300.HWId;
        h300name
        hname = hEmant.HWId;
        hname
        
        if(saveD)
            fileID = fopen('saveData.txt', 'w');
            fID = fopen('IVCurveData.txt','w');
            fprintf(fileID,'Time          V               R              S   \n');
            fprintf( fID, 'Time (s)      Voltage \n');      
        end
        %Initialize all required variables
        tstart = tic; %start a stopwatch
        y = [];
        x = [];
        c = []; % this is for the control curve.

        std_dev1 = [];
        std_dev2 = [];
        hold on;
        telapsed = 0;
        TIME_OFFSET = 0.5;

        %RUN NESTED LOOP
        while telapsed <= tmax

            n = 1;
            amp = 0:deltaA:Amax;
            for A = 0:deltaA:Amax %do a current sweep and measure voltages from the emant card and plot them.
                hEmant300.WriteAnalog(A);
                hEmant.WriteAnalog(A);
                volt(n) = hEmant300.ReadAnalog('AIN_AIN2','AIN_AIN3');
                voltc(n) = hEmant.ReadAnalog('AIN_AIN2', 'AIN_AIN3');
                volt
                voltc
                n = n+1;
            end
            hold off
            %disp(amp);
            %disp(volt); 

            %Run a polynomial fit for the first set of data (not control)
            p = polyfit(amp,volt,2); %get a second degree polynomial for the IV curves.
            S = p(1);
            R = 1000*p(2);
            
            %this is for the control sample.
            p1 = polyfit(amp,voltc,2); %get a second degree polynomial for control IV curves.
            r1 = 1000*p1(2);
            %disp(R);

            %create vectors for plotting
            telapsed = toc(tstart);
            c = [c r1];
            y = [y R];        
            x = [x telapsed];

             if(saveD)
                fprintf( fileID, '%f      %f      %f     %f \n',telapsed, V, R, S);
                fprintf(fID, '%f      ', telapsed);
                printVector(fID, volt);
             end

            [ax,h1,h2] = plotyy( x, y, x + TIME_OFFSET, c,'scatter');
            set(h1,'markerfacecolor','r')
            set(h2,'markerfacecolor','b')
            set(ax,{'ycolor'},{'r';'b'})
            title('Conductivity Curve');
            xlabel('Time (s)');
            ylabel(ax(1),'Resistance (ohm): Main');
            ylabel(ax(2),'Resistance (ohm): Control');


            if(error)

                s1 = std(y);
                std_dev1 = [std_dev1 s1];

                s2 = std(c);  
                std_dev2 = [std_dev2 s2];

                %disp(std_dev); can be used for debugging
            end

        drawnow;
        hEmant300.WriteAnalog(0);        
        hEmant.WriteAnalog(0);
        
        end %end while loop
        hold off;

        if(error)            
            hold(ax(1), 'on');
            errorbar(ax(1), x, y, std_dev1, 'LineStyle', 'none','Color','r');            
            hold(ax(2), 'on');
            errorbar(ax(2), x + TIME_OFFSET, c, std_dev2, 'LineStyle', 'none','Color','b');
            hold off

        end
        if(saveD)
            fclose(fileID);
            fprintf(fID, '\nThe next line will be the amperage associated with each of the voltage vectors\n');
            printVector(fID,amp);
            fclose(fID);
        end
        
        hEmant300.WriteAnalog(0);
        hEmant300.Close;
        
        hEmant.WriteAnalog(0);
        hEmant.Close;
        
    catch
        warndlg('Unable to make connection with controlling device. Please ensure proper contacts and try again. Matlab will now restart.');
        pause(8);
        system('matlab &');quit
        %GUI_RMT;
    end
    A = [x' y'];
    save test.txt A -ascii;

    