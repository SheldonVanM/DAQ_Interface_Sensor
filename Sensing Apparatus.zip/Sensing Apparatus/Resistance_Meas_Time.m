%Authors: Sheldon Van Middelkoop
%Version 2.1
%Title: Resistance_Meas_Time.m
%Description:
%Program to push out a current and measure a voltage
%Will plot with respect to time.
%Test case for more complex program to do sensing of conductivity
function Resistance_Meas_Time(Amax, deltaA, tmax, error, saveD,resDEC)
    
    %resDEC = 45000;
    %Simple exception handling, if fails open card the program doesn't fail
    try
         %Open the emant card
        hEmant300 = actxserver('EMANT300COM.Wrapper', 'COM7'); %gains access to wrapper class.
        hEmant300.Open;
        
    catch
        warndlg('Unable to make connection with controlling device. Please ensure proper connections and try again.');
        GUI_RMT;
    end
        %saveD
        %If the user wants to save there data we will open the two files
        %where we are storing our data and create headers for both files
        if(saveD)
            fileID = fopen('saveData.txt', 'w');
            fID = fopen('IVCurveData.txt','w');
            fprintf(fileID,'Time \t\t\t\t V \t\t\t\t\t R \t\t\t\t\t\t S \t\t\t\t\t\t Current Factor \n');
            fprintf(fileID,'-----\t\t\t\t ------- \t\t\t ------- \t\t\t\t ------- \t\t\t\t ------- \n');
            fprintf( fID, 'Time (s)      Voltage \n');      
        end
        %Initialize all required variables
        tstart = tic; %start a stopwatch
        y = [];
        x = [];
        std_dev1 = [];
        hold on;
        telapsed = 0;
        
        %RUN NESTED LOOP
        %Run program until time has elapsed
        while telapsed <= tmax
            n = 1;
            amp = deltaA:deltaA:Amax;
            for A = deltaA:deltaA:Amax %do a current sweep and measure voltages from the emant card and plot them.
                %disp(hEmant300);
                %Supply our current
                hEmant300.WriteAnalog(A);
                %obj.Timeout(20);
                %Read out our voltage
                volt(n) = hEmant300.ReadAnalog('AIN_AIN2','AIN_AIN3'); 
                n = n+1;
            end
            
            hold off
            %disp(amp);
            %disp(volt); 

            %Run a polynomial fit for the first set of data (not control)
            p = polyfit(amp,volt,2); %get a second degree polynomial for the IV curves.
            S = 1000*p(1);
            R_EQ = 1000*p(2);
            V = 1000*p(3); 
            R = abs(((R_EQ*resDEC)/(resDEC-R_EQ)));
            %disp(R);
            %create vectors for plotting
            telapsed = toc(tstart);
            y = [y R];        
            x = [x telapsed];
            
            %Write 
            if(saveD)
                fprintf( fileID, '%f \t\t\t %f \t\t\t %f \t\t\t %f \t\t\t %f\n',telapsed, V, R, S, resDEC/(resDEC+R));
                fprintf(fID, '%f      ', telapsed);
                printVector(fID, volt);
            end
            volt = [];
            %make sure emant does not read any lingering voltages
            %hEmant300.WriteAnalog(0); 

             %if user does not want control experiment only plot the main figure      
            plot(x,y, 'ro');
            title('Resistance Measurements');
            xlabel('Time (s)');
            ylabel('Resistance (ohms)');
            axis([0 telapsed 0 max(y)+1000]);
            %IF user wants error bars compute standard deviation
            if(error)
                s1 = std(y);
                std_dev1 = [std_dev1 s1];                
            end
            drawnow;
            hEmant300.WriteAnalog(0);
        end %end while loop
        hold off;
        %IF user wants error bars plot standard deviation
        if(error)        

            hold on
            errorbar(x, y , std_dev1, 'LineStyle','none');
            hold off
        end
        %Close up the files where data is being stored
        if(saveD)
            fclose(fileID);
            fprintf(fID, '\nThe next line will be the amperage associated with each of the voltage vectors\n');
            printVector(fID,amp);
            fclose(fID);
            warndlg('Save this data to a permanent file as the file saveData.txt and IVCurveData.txt will be overwritten next run!!!');
        end
        %Close card and get rid of floating voltages
        hEmant300.WriteAnalog(0);
        hEmant300.Close;
        disp('Run was successful');
    A = [x' y'];
    hEmant300.Close;
    save test.txt A -ascii;
